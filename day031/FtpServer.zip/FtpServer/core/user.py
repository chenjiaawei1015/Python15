import os
import hashlib
import pickle
import struct

from conf import config

from loguru import logger


class User:

    def __init__(self, username, password):
        self.username = username
        self.password = password
        self.current_dir = None
        self.user_root_dir = None

    @staticmethod
    def login(username, password):
        """
        登录
        :param username: 用户名
        :param password: 密码(md5)
        :return: 登录结果
        """
        login_path = os.path.join(config.BASE_DIR, "db", "login.txt")

        user_exist = False
        with open(login_path, "r") as login_f:
            for line in login_f:
                username_f, pwd_f = line.strip().split("|")
                if username_f == username and pwd_f == password:
                    user_exist = True
                    break
        return user_exist

    def create_user_dir(self):
        """
        在登录用户目录下创建一个文件夹
        :return:
        """
        self.current_dir = config.USER_BASE_DIR
        self.mkdirs(self.username)
        self.user_root_dir = self.current_dir

    def mkdirs(self, dir_name):
        """
        创建文件夹
        :param dir_name: 文件夹名称
        :return:
        """
        dst_dir_path = os.path.join(self.current_dir, dir_name)
        self.current_dir = dst_dir_path
        if os.path.exists(dst_dir_path) and os.path.isdir(dst_dir_path):
            pass
        else:
            os.makedirs(dst_dir_path)

    def create_new_file(self, file_name):
        """
        创建文件
        :param file_name: 文件名称
        :return:
        """
        dst_file_path = os.path.join(self.current_dir, file_name)
        if os.path.exists(dst_file_path) and os.path.isfile(dst_file_path):
            pass
        else:
            with open(dst_file_path, "wb") as det_f:
                pass

    def remove_dir(self, dir_name):
        """
        删除目录
        :param dir_name:
        :return:
        """
        dst_dir_path = os.path.join(self.current_dir, dir_name)
        if os.path.exists(dst_dir_path) and os.path.isdir(dst_dir_path) and not len(os.listdir(dst_dir_path)):
            os.removedirs(dst_dir_path)
            return True
        return False

    def remove_file(self, file_name):
        """
        删除文件
        :param file_name:
        :return:
        """
        dst_file_path = os.path.join(self.current_dir, file_name)
        if os.path.exists(dst_file_path) and os.path.isfile(dst_file_path):
            os.remove(dst_file_path)
            return True
        return False

    def ls(self):
        """
        查看当前目录下所有的文件与文件夹
        :return:
        """
        return os.listdir(self.current_dir)

    def cd(self, command):
        """
        切换目录
        :param command:
        :return:
        """
        command = command.strip()
        if command == "..":
            self.current_dir = os.path.dirname(self.current_dir)
            return

        temp_path_list = command.split("/")
        if len(temp_path_list) and temp_path_list[0] == '':
            self.current_dir = self.user_root_dir

        for item_path in temp_path_list:
            self.current_dir = os.path.join(self.current_dir, item_path)

    def pwd(self):
        """
        查看当前目录
        :return:
        """
        return self.current_dir

    def prepare_upload(self, file_name):
        """
        上传文件 预备动作
        :param file_name:
        :return: 图片文件的大小
        """
        file_path = os.path.join(self.current_dir, file_name)
        if os.path.exists(file_path) and os.path.isfile(file_path):
            return os.path.getsize(file_path)
        return 0

    def upload(self, request, header):
        """
        上传文件
        :param request:
        :param header:
        :return:
        """
        file_path = os.path.join(self.current_dir, header[config.PARAMS_FILE_NAME])

        current_write_size = 0
        with open(file_path, "ab") as dst_f:
            while current_write_size < header[config.PARAMS_BODY_SIZE]:
                data = request.recv(config.BUF_SIZE)
                if not data:
                    break
                dst_f.write(data)
                current_write_size += len(data)

        # 比较文件的 Md5 值
        file_md5_obj = hashlib.md5()
        with open(file_path, "rb") as src_f:
            for data in src_f:
                file_md5_obj.update(data)
            file_md5 = file_md5_obj.hexdigest()
        logger.debug(f"上传文件的 MD5 : {file_md5}")
        return file_md5 == header[config.PARAMS_FILE_MD5]

    def download(self, request, header, file_name):
        """
        下载文件
        :param request:
        :param header:
        :return:
        """
        file_path = os.path.join(self.current_dir, file_name)

        # 计算文件的MD5值
        file_md5_obj = hashlib.md5()
        with open(file_path, "rb") as src_f:
            for data in src_f:
                file_md5_obj.update(data)
            file_md5 = file_md5_obj.hexdigest()
            logger.debug(f"下载文件的md5值 : {file_md5}")

        # 剩余下载文件的长度
        less_download_size = os.path.getsize(file_path) - header[config.PARAMS_FILE_SIZE]

        response_header = {
            config.PARAMS_COMMAND: "download",
            config.PARAMS_BODY_SIZE: less_download_size,
            config.PARAMS_FILE_MD5: file_md5
        }

        response_header_byte = pickle.dumps(response_header)
        pack_data = struct.pack("i", len(response_header_byte))

        request.send(pack_data)
        request.send(response_header_byte)

        with open(file_path, "rb") as src_f:
            src_f.seek(header[config.PARAMS_FILE_SIZE])
            for data in src_f:
                request.send(data)


if __name__ == '__main__':
    # import hashlib
    #
    # obj = hashlib.md5()
    # obj.update(b"123456")
    # value = obj.hexdigest()
    # print(value)

    s1 = ["aa", "aa/bb", "/aa", "aa/", ""]
    for item in s1:
        print(item.split("/"))

    pass
