import pickle
import struct

from loguru import logger

from core import server
from conf import config
from core.user import User


class Main:
    LOGIN_USER_DICT = dict()

    @staticmethod
    def handle_request_data(request, header):
        """
        处理请求

        {
        "command":"login"
        "body_size":100
        }
        aaa 111

        :param request: 客户端socket
        :param header: 请求头(字典)
        :return:
        """

        command = header[config.PARAMS_COMMAND]

        if hasattr(Main, command):
            func = getattr(Main, command)
            return func(request, header)

    @staticmethod
    def start():
        """
        开启服务端
        :return:
        """
        sk_server = server.MyServer(Main.handle_request_data)
        sk_server.start()

    @staticmethod
    def response_data(request, header, body_byte):
        """
        回响应数据给客户端
        :param request: 客户端socket
        :param header: 请求头
        :param body_byte: 请求头(字节)
        :return:
        """
        header_byte = pickle.dumps(header)
        header_byte_len = struct.pack("i", len(header_byte))

        request.send(header_byte_len)
        logger.debug("")
        request.send(header_byte)
        request.send(body_byte)

    @staticmethod
    def login(request, header):
        """
        登录
        :param request:
        :param header:
        :return:
        """
        request_body = str(request.recv(header[config.PARAMS_BODY_SIZE]), config.UTF8_ENCODING).strip()
        username, password = request_body.split(" ")

        login_res = User.login(username, password)

        if login_res:
            response_body = config.RESULT_SUCCESS

            user = User(username, password)
            Main.LOGIN_USER_DICT[username] = user
            user.create_user_dir()
        else:
            response_body = config.RESULT_FAILED
        return Main.generate_response_for_string(response_body, "login")

    @staticmethod
    def mkdirs(request, header):
        """
        创建文件夹
        :param request:
        :param header:
        :return:
        """
        request_body = str(request.recv(header[config.PARAMS_BODY_SIZE]), config.UTF8_ENCODING).strip()

        current_user = Main.LOGIN_USER_DICT.get(header[config.PARAMS_LOGIN_USER])
        current_user.mkdirs(request_body)
        return Main.generate_response_for_string(config.RESULT_SUCCESS, "mkdirs")

    @staticmethod
    def create_new_file(request, header):
        """
        创建文件
        :param request:
        :param header:
        :return:
        """
        request_body = str(request.recv(header[config.PARAMS_BODY_SIZE]), config.UTF8_ENCODING).strip()

        current_user = Main.LOGIN_USER_DICT.get(header[config.PARAMS_LOGIN_USER])
        current_user.create_new_file(request_body)
        return Main.generate_response_for_string(config.RESULT_SUCCESS, "create_new_file")

    @staticmethod
    def remove_dir(request, header):
        """
        删除文件目录
        :param request:
        :param header:
        :return:
        """
        request_body = str(request.recv(header[config.PARAMS_BODY_SIZE]), config.UTF8_ENCODING).strip()

        current_user = Main.LOGIN_USER_DICT.get(header[config.PARAMS_LOGIN_USER])
        res = current_user.remove_dir(request_body)
        return Main.generate_response_for_string(config.RESULT_SUCCESS if res else config.RESULT_FAILED, "remove_dir")

    @staticmethod
    def remove_file(request, header):
        """
        删除文件
        :param request:
        :param header:
        :return:
        """
        request_body = str(request.recv(header[config.PARAMS_BODY_SIZE]), config.UTF8_ENCODING).strip()

        current_user = Main.LOGIN_USER_DICT.get(header[config.PARAMS_LOGIN_USER])
        res = current_user.remove_file(request_body)
        return Main.generate_response_for_string(config.RESULT_SUCCESS if res else config.RESULT_FAILED, "remove_file")

    @staticmethod
    def ls(request, header):
        """
        查看当前目录下所有的文件与文件夹
        :param request:
        :param header:
        :return:
        """
        request_body = str(request.recv(header[config.PARAMS_BODY_SIZE]), config.UTF8_ENCODING).strip()
        current_user = Main.LOGIN_USER_DICT.get(header[config.PARAMS_LOGIN_USER])

        file_list = current_user.ls()
        response_body = pickle.dumps(file_list)
        return Main.generate_response_for_byte(response_body, "ls")

    @staticmethod
    def pwd(request, header):
        """
        查看当前目录
        :param request:
        :param header:
        :return:
        """
        request_body = str(request.recv(header[config.PARAMS_BODY_SIZE]), config.UTF8_ENCODING).strip()
        current_user = Main.LOGIN_USER_DICT.get(header[config.PARAMS_LOGIN_USER])

        res_path = current_user.pwd()
        return Main.generate_response_for_string(res_path, "pwd")

    @staticmethod
    def cd(request, header):
        """
        切换目录
        :param request:
        :param header:
        :return:
        """
        request_body = str(request.recv(header[config.PARAMS_BODY_SIZE]), config.UTF8_ENCODING).strip()
        current_user = Main.LOGIN_USER_DICT.get(header[config.PARAMS_LOGIN_USER])
        current_user.cd(request_body)
        return Main.generate_response_for_string(config.RESULT_SUCCESS, "cd")

    @staticmethod
    def prepare_upload(request, header):
        """
        上传文件 预备动作
        :param request:
        :param header:
        :return:
        """
        request_body = str(request.recv(header[config.PARAMS_BODY_SIZE]), config.UTF8_ENCODING).strip()
        current_user = Main.LOGIN_USER_DICT.get(header[config.PARAMS_LOGIN_USER])
        file_size = current_user.prepare_upload(request_body)
        return Main.generate_response_for_string(str(file_size), "prepare_upload")

    @staticmethod
    def upload(request, header):
        """
        上传文件
        :param request:
        :param header:
        :return:
        """
        current_user = Main.LOGIN_USER_DICT.get(header[config.PARAMS_LOGIN_USER])
        res = current_user.upload(request, header)
        return Main.generate_response_for_string(config.RESULT_SUCCESS if res else config.RESULT_FAILED, "upload")

    @staticmethod
    def download(request, header):
        """
        下载文件
        :param request:
        :param header:
        :return:
        """
        request_body = str(request.recv(header[config.PARAMS_BODY_SIZE]), config.UTF8_ENCODING).strip()
        current_user = Main.LOGIN_USER_DICT.get(header[config.PARAMS_LOGIN_USER])
        current_user.download(request, header, request_body)
        logger.debug(f"下载文件请求体 : {request_body}")
        pass

    @staticmethod
    def generate_response_for_byte(response_body, command):
        """
        生产响应对象
        :param response_body:
        :param command:
        :return:
        """
        response_head = {
            config.PARAMS_COMMAND: command,
            config.PARAMS_BODY_SIZE: len(response_body)
        }
        yield response_head
        yield response_body

    @staticmethod
    def generate_response_for_string(response_body, command):
        """
        生产响应对象
        :param response_body: 请求体
        :param command: 命令
        :return:
        """
        response_body_byte = bytes(response_body, config.UTF8_ENCODING)
        return Main.generate_response_for_byte(response_body_byte, command)
