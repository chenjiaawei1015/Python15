import socketserver
import traceback
import struct
import pickle

from loguru import logger

from conf import config


class MyRequestServer(socketserver.BaseRequestHandler):

    def handle(self):
        logger.info(f"客户端 {self.client_address} 连接成功")

        try:
            while 1:
                # 获取请求头长度
                response_data = self.request.recv(4)
                header_len = struct.unpack("i", response_data)[0]
                if not header_len:
                    break

                # 获取请求头信息
                header_byte = self.request.recv(header_len)
                header = pickle.loads(header_byte)

                logger.debug(f"请求头数据 : {header}")

                if not hasattr(self.server, "call_back_func"):
                    continue

                func = getattr(self.server, "call_back_func")
                response_gen = func(self.request, header)
                if not response_gen:
                    continue

                response_head = next(response_gen)
                logger.debug(f"响应头数据 : {response_head}")

                response_head_byte = pickle.dumps(response_head)

                response_pack_data = struct.pack("i", len(response_head_byte))
                self.request.send(response_pack_data)

                # 发送响应头
                self.request.send(response_head_byte)

                # 发送响应体
                for item_response_body in response_gen:
                    self.request.send(item_response_body)

        except Exception:
            traceback.print_exception()
        finally:
            self.request.close()


class MyServer:

    def __init__(self, call_back_func=None):
        self.call_back_func = call_back_func

    def start(self):
        socketserver.allow_reuse_address = True
        sk = socketserver.ThreadingTCPServer(config.IP_PORT, MyRequestServer)
        sk.call_back_func = self.call_back_func
        logger.info("服务端开启")
        sk.serve_forever()
