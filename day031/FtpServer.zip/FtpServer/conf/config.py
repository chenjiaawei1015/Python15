import os

IP_PORT = ("127.0.0.1", 28116)

UTF8_ENCODING = "utf-8"

BUF_SIZE = 1024 * 1024

# 指向 FtpServer 路径
BASE_DIR = os.path.dirname(os.getcwd())

# 指向 db 目录
USER_BASE_DIR = os.path.join(BASE_DIR, "db")

PARAMS_COMMAND = "command"
PARAMS_BODY_SIZE = "body_size"
PARAMS_LOGIN_USER = "login_user"
PARAMS_FILE_NAME = "file_name"
PARAMS_FILE_SIZE = "file_size"
PARAMS_FILE_MD5 = "file_md5"

RESULT_SUCCESS = "1"
RESULT_FAILED = "0"
