import socket
import hashlib
import struct
import pickle
import traceback
import os
import time

from loguru import logger

from conf import config

"""
命令大全

登录
    login 用户名 密码

创建文件夹
    mkdirs 文件夹名称
    
创建文件
    create_new_file 文件名
    
删除文件夹
    remove_dir 文件夹名称
    
删除文件
    remove_file 文件名
    
查看当前目录下所有的文件与文件夹
    ls 
    
切换目录
    cd ..
    cd dir1
    cd dir1/dir2
    cd /dir1
    
查看当前目录
    pwd
    
上传文件
    upload 文件名
    
下载文件
    download 文件名

"""


class Client:

    def __init__(self):
        self.sk = socket.socket()
        self.sk.connect(config.IP_PORT)
        self.login_user = None
        logger.info("客户端连接成功")

    def parse_response_header_byte_body(self):
        response_gen = self.recv_response_data()
        # 响应头
        response_header = next(response_gen)

        # 响应体
        response_body_byte = bytes()
        for item_response_body_byte in response_gen:
            response_body_byte += item_response_body_byte

        logger.debug(f"响应体数据 : {response_body_byte}")
        return response_header, response_body_byte

    def parse_response_header_string_body(self):
        response_gen = self.recv_response_data()
        # 响应头
        response_header = next(response_gen)

        # 响应体
        response_body_byte = bytes()
        for item_response_body_byte in response_gen:
            response_body_byte += item_response_body_byte

        response_body = str(response_body_byte, config.UTF8_ENCODING)
        logger.debug(f"响应体数据 : {response_body}")

        return response_header, response_body

    def recv_response_data(self):
        """
        接收服务端的响应数据
        :return:
        """
        response_data_len = struct.unpack("i", self.sk.recv(4))[0]
        # 接收响应头
        header_bytes = self.sk.recv(response_data_len)
        header = pickle.loads(header_bytes)
        logger.debug(f"响应头信息 : {header}")
        yield header

        # 接收响应体
        current_response_data_len = 0
        while current_response_data_len < header[config.PARAMS_BODY_SIZE]:
            response_data_byte = self.sk.recv(config.BUF_SIZE)
            current_response_data_len += len(response_data_byte)
            yield response_data_byte

    def send_request_data(self, command, request_body):
        """
        发送请求
        :param command: 命令
        :param request_body: 请求体数据 (字节类型)
        :return:
        """

        # 构建请求头
        request_header = {
            config.PARAMS_COMMAND: command,
            config.PARAMS_BODY_SIZE: len(request_body),
        }

        if self.login_user:
            request_header[config.PARAMS_LOGIN_USER] = self.login_user

        header_bytes = pickle.dumps(request_header)
        pack_data = struct.pack("i", len(header_bytes))

        # 发送4字节信息
        self.sk.send(pack_data)
        # 发送请求头
        self.sk.send(header_bytes)
        # 发送请求体
        self.sk.send(request_body)

    def login(self, command):
        """
        登录操作
        :param command: 命令: login 用户名 密码
        :return:
        """
        logger.info("进行登录操作")

        username, password = command.split(" ")

        md5_obj = hashlib.md5()
        md5_obj.update(bytes(password, config.UTF8_ENCODING))
        password_md5 = md5_obj.hexdigest()

        # 请求体
        request_data = f"{username} {password_md5}"
        self.send_request_data("login", bytes(request_data, config.UTF8_ENCODING))

        # 响应头
        response_header, response_body = self.parse_response_header_string_body()

        logger.debug(f"登录结果 : {response_body == config.RESULT_SUCCESS}")

        if config.RESULT_SUCCESS == response_body:
            self.login_user = username
        return response_body == config.RESULT_SUCCESS

    def mkdirs(self, command):
        """
        创建文件夹
        :param command: 文件夹名称
        :return:
        """
        self.send_request_data("mkdirs", bytes(command, config.UTF8_ENCODING))

        # 响应头
        response_header, response_body = self.parse_response_header_string_body()

        logger.debug(f"文件夹的创建结果 : {config.RESULT_SUCCESS == response_body}")

    def create_new_file(self, command):
        """
        创建文件
        :param command: 文件名
        :return:
        """
        self.send_request_data("create_new_file", bytes(command, config.UTF8_ENCODING))

        # 响应头
        response_header, response_body = self.parse_response_header_string_body()

        logger.debug(f"文件的创建结果 : {config.RESULT_SUCCESS == response_body}")

    def remove_dir(self, command):
        """
        删除目录
        :param command:
        :return:
        """
        self.send_request_data("remove_dir", bytes(command, config.UTF8_ENCODING))

        # 响应头
        response_header, response_body = self.parse_response_header_string_body()

        logger.debug(f"文件目录删除结果 : {config.RESULT_SUCCESS == response_body}")

    def remove_file(self, command):
        """
        删除文件
        :param command:
        :return:
        """
        self.send_request_data("remove_file", bytes(command, config.UTF8_ENCODING))

        # 响应头
        response_header, response_body = self.parse_response_header_string_body()

        logger.debug(f"文件删除结果 : {config.RESULT_SUCCESS == response_body}")

    def ls(self, command=None):
        """
        查看当前目录下所有的文件与文件夹
        :param command:
        :return:
        """
        self.send_request_data("ls", bytes(" ", config.UTF8_ENCODING))
        # 响应头
        response_header, response_body = self.parse_response_header_byte_body()

        file_list = pickle.loads(response_body)
        for item_file_name in file_list:
            logger.debug(item_file_name)

    def pwd(self, command=None):
        """
        查看当前目录
        :param command:
        :return:
        """
        self.send_request_data("pwd", bytes(" ", config.UTF8_ENCODING))
        # 响应头
        response_header, response_body = self.parse_response_header_string_body()
        logger.debug(f"当前目录 : {response_body}")

    def cd(self, command):
        """
        切换目录
        :param command:
        :return:
        """
        self.send_request_data("cd", bytes(command, config.UTF8_ENCODING))
        # 响应头
        response_header, response_body = self.parse_response_header_string_body()
        logger.debug(f"切换目录结果 : {config.RESULT_SUCCESS == response_body}")

    def __prepare_upload(self, command):
        """
        上传文件 预备动作
        :param command:
        :return:
        """
        self.send_request_data("prepare_upload", bytes(command, config.UTF8_ENCODING))
        # 响应头
        response_header, response_body = self.parse_response_header_string_body()
        return response_body

    def upload(self, command):
        """
        上传文件
        :param command:
        :return:
        """
        response_file_size = int(self.__prepare_upload(command))
        logger.debug(f"服务端已上传文件的大小 : {response_file_size}")
        file_path = os.path.join(config.DB_DIR, command)

        # 上传文件的大小
        upload_size = os.path.getsize(file_path) - response_file_size
        logger.debug(f"剩余上传大小 : {upload_size}")

        request_header = {
            config.PARAMS_COMMAND: "upload",
            config.PARAMS_BODY_SIZE: upload_size,
            config.PARAMS_FILE_NAME: command
        }

        if self.login_user:
            request_header[config.PARAMS_LOGIN_USER] = self.login_user

        # 计算文件的 Md5 值
        file_md5_obj = hashlib.md5()
        with open(file_path, "rb") as src_f:
            for data in src_f:
                file_md5_obj.update(data)
            file_md5 = file_md5_obj.hexdigest()
        request_header[config.PARAMS_FILE_MD5] = file_md5

        logger.debug(f"上传文件请求头 : {request_header}")

        # 请求头
        request_header_byte = pickle.dumps(request_header)

        pack_data = struct.pack("i", len(request_header_byte))
        self.sk.send(pack_data)
        self.sk.send(request_header_byte)

        # 请求体
        with open(file_path, "rb") as src_f:
            src_f.seek(response_file_size)
            for data in src_f:
                # time.sleep(0.001)
                # 发送文件
                self.sk.send(data)
                pass

        response_header, response_body = self.parse_response_header_string_body()
        if config.RESULT_SUCCESS == response_body:
            logger.debug("上传完成")
        else:
            logger.debug("上传失败")

    def download(self, command):
        """
        下载文件
        :return:
        """
        file_path = os.path.join(config.DB_DIR, command)
        # 当前下载的大小
        file_path_size = 0
        if os.path.exists(file_path) and os.path.isfile(file_path):
            file_path_size = os.path.getsize(file_path)

        # 请求体
        request_body = bytes(command, config.UTF8_ENCODING)

        request_header = {
            config.PARAMS_COMMAND: "download",
            config.PARAMS_BODY_SIZE: len(request_body),
            config.PARAMS_FILE_SIZE: file_path_size,
            config.PARAMS_LOGIN_USER: self.login_user
        }

        request_header_byte = pickle.dumps(request_header)
        pack_data = struct.pack("i", len(request_header_byte))

        # 请求体与请求体的发送
        self.sk.send(pack_data)
        self.sk.send(request_header_byte)
        self.sk.send(request_body)

        # 接收数据
        response_header_byte_len = struct.unpack("i", self.sk.recv(4))[0]
        response_header = pickle.loads(self.sk.recv(response_header_byte_len))
        logger.debug(f"下载文件 响应头 : {response_header}")

        current_write_size = 0
        with open(file_path, "ab") as dst_f:
            while current_write_size < response_header[config.PARAMS_BODY_SIZE]:
                # time.sleep(0.005)
                data = self.sk.recv(config.BUF_SIZE)
                if not data:
                    continue
                dst_f.write(data)
                current_write_size += len(data)
        logger.debug("下载文件完成")

        # 比较下载文件的Md5值
        file_md5_obj = hashlib.md5()
        with open(file_path, "rb") as dst_f:
            for data in dst_f:
                file_md5_obj.update(data)
            file_md5 = file_md5_obj.hexdigest()
            logger.debug(f"文件MD5 : {file_md5}")

        if file_md5 == response_header[config.PARAMS_FILE_MD5]:
            logger.debug("文件下载成功")
        else:
            logger.debug("文件下载失败")

    def start(self):
        try:
            while 1:
                command = input("请输入命令 : ").strip()
                if not command:
                    continue

                func_name = command.split(" ")[0]

                if hasattr(self, func_name):
                    func = getattr(self, func_name)
                    func(command[len(func_name):].strip())

        except Exception:
            traceback.print_exception()
        finally:
            self.sk.close()


if __name__ == '__main__':
    c = Client()
    c.start()
