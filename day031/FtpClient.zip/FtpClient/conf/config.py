import os

IP_PORT = ("127.0.0.1", 28116)

UTF8_ENCODING = "utf-8"

BUF_SIZE = 1024

# 指向 FtpServer 路径
BASE_DIR = os.path.dirname(os.getcwd())

PARAMS_COMMAND = "command"
PARAMS_BODY_SIZE = "body_size"
PARAMS_LOGIN_USER = "login_user"
PARAMS_FILE_NAME = "file_name"
PARAMS_FILE_SIZE = "file_size"
PARAMS_FILE_MD5 = "file_md5"

RESULT_SUCCESS = "1"
RESULT_FAILED = "0"

RESPONSE_HEADER = "response_header"
RESPONSE_BODY = "response_body"

# 指向 db 路径
DB_DIR = os.path.join(BASE_DIR, "db")
